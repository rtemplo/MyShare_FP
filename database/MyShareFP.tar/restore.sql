--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.4
-- Dumped by pg_dump version 10.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

DROP TRIGGER last_updated_on ON public.email_subscriber;
DROP INDEX public.idx_email_subscriber_last_name;
DROP INDEX public.idx_email_subscriber_email;
ALTER TABLE ONLY public.email_subscriber DROP CONSTRAINT email_subscriber_pkey;
ALTER TABLE ONLY public.email_subscriber DROP CONSTRAINT email_subscriber_email_key;
ALTER TABLE public.email_subscriber ALTER COLUMN sub_id DROP DEFAULT;
DROP SEQUENCE public.email_subscriber_sub_id_seq;
DROP TABLE public.email_subscriber;
DROP FUNCTION public.last_updated_on();
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: last_updated_on(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.last_updated_on() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

BEGIN
    NEW.last_updated_on = CURRENT_TIMESTAMP;
    RETURN NEW;
END 
$$;


ALTER FUNCTION public.last_updated_on() OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: email_subscriber; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.email_subscriber (
    sub_id integer NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    email character varying(355) NOT NULL,
    created_on timestamp without time zone DEFAULT now() NOT NULL,
    last_updated_on timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.email_subscriber OWNER TO postgres;

--
-- Name: email_subscriber_sub_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.email_subscriber_sub_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.email_subscriber_sub_id_seq OWNER TO postgres;

--
-- Name: email_subscriber_sub_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.email_subscriber_sub_id_seq OWNED BY public.email_subscriber.sub_id;


--
-- Name: email_subscriber sub_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_subscriber ALTER COLUMN sub_id SET DEFAULT nextval('public.email_subscriber_sub_id_seq'::regclass);


--
-- Data for Name: email_subscriber; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.email_subscriber (sub_id, first_name, last_name, email, created_on, last_updated_on) FROM stdin;
\.
COPY public.email_subscriber (sub_id, first_name, last_name, email, created_on, last_updated_on) FROM '$$PATH$$/2803.dat';

--
-- Name: email_subscriber_sub_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.email_subscriber_sub_id_seq', 5, true);


--
-- Name: email_subscriber email_subscriber_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_subscriber
    ADD CONSTRAINT email_subscriber_email_key UNIQUE (email);


--
-- Name: email_subscriber email_subscriber_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_subscriber
    ADD CONSTRAINT email_subscriber_pkey PRIMARY KEY (sub_id);


--
-- Name: idx_email_subscriber_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_email_subscriber_email ON public.email_subscriber USING btree (email);


--
-- Name: idx_email_subscriber_last_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_email_subscriber_last_name ON public.email_subscriber USING btree (last_name);


--
-- Name: email_subscriber last_updated_on; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER last_updated_on BEFORE UPDATE ON public.email_subscriber FOR EACH ROW EXECUTE PROCEDURE public.last_updated_on();


--
-- PostgreSQL database dump complete
--

